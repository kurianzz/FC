package com.citi.servlet;

import java.io.*;
import java.util.*;


public class commonResources {
	private String header;
	private String footer;
	private List<String> fileContents;
	private List<String> appsList;
	//Properties
	private String lbfiledir;
	private String lbappfile;
	private String lburlpath;
	
	
	public List<String> readFile(String file) {
		//
		List<String> contents = new ArrayList<String>();
	    try {
	    	File f = new File(file);
			BufferedReader br = new BufferedReader(new FileReader(f));
		    String line;
		    while ((line = br.readLine()) != null) {
		    //    System.out.println(line);
		        contents.add(line);
		    }
		    br.close();
		    
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return contents;
	}
	
	public void setHeader() {
		this.header = "<!DOCTYPE html>\n" +
		   "<html>\n" +
		   "<title>W3.CSS Template</title>\n" +
		   "<meta charset=\"UTF-8\">\n" + 
		   "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" + 
		   "<link rel=\"stylesheet\" href=\"/css/style.css\">\n" +
		   "<link rel=\"stylesheet\" href=\"/css/font-awesome.min.css\">\n" +
		   "<style>\n" + 
		   "html,body,h1,h2,h3,h4,h5 {font-family: \"Raleway\", sans-serif}\n" +
		   "</style>\n" +
		   "<body>\n" +
		   "<div>\n" +
		   "<div class=\"mainheader\">\n" +
		   "<p style=\"margin-top:5px; font-size: 25px; font-weight: bold;\">TIBCO Inventory</p>\n" +
		   "<div style=\"margin-top:-15px\">\n" +
		   "<ul>\n" +
		   "<li style=\"float:left;\"><a style=\"color:white;\" href=\"#home\">Home</a></li>\n" +
		   "<li style=\"float:left;\"><a style=\"color:white;\" href=\""+ getlblburlpath() + "/\">Load Balancer</a></li>\n" +
		   "<li style=\"float:left;\"><a style=\"color:white;\" href=\"#contact\">Contact</a></li>\n" +
		   "<li style=\"float:left;\"><a style=\"color:white;\" href=\"#about\">About</a></li>\n" +
		   "</ul>\n" +
		   "</div>\n" +
		   "</div>\n";
	}
	public String getHeader(){	
		return header;
	}
	
	public void setFooter() {
		this.footer ="</table>\n" +	
				"</div>\n" +
				"</div>\n" +
				"<!-- Footer -->\n" +
				"<footer>\n" +
				"<div>\n" +
				"</div>\n" +
				"</footer>\n" +		
				"<!-- End of Footer -->\n" +
				"</div>\n" +
				"<script>\n" +
				"// Accordion\n" +
				"function myFunction(id) {\n" +
				"var x = document.getElementById(id);\n" +
				"if (x.className.indexOf(\"w3-show\") == -1) {\n" +
				"x.className += \" w3-show\";\n" +
				"x.previousElementSibling.className += \" w3-theme-d1\";\n" +
				"} else { \n" +
				"x.className = x.className.replace(\"w3-show\", \"\");\n" +
				"x.previousElementSibling.className = \n" +
				"x.previousElementSibling.className.replace(\" w3-theme-d1\", \"\");\n" +
				"}\n" +
				"}\n" +
				"</script>\n" +
				"<!--Sortable table header-->\n" +
				"<script>\n" +
				"function sortTable(n,id) {\n" +
				"var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;\n" +
				"table = document.getElementById(id);\n" +
				"switching = true;\n" +
				"//Set the sorting direction to ascending:\n" +
				"dir = \"asc\"; \n" +
				"/*Make a loop that will continue until\n" +
				"no switching has been done:*/\n" +
				"while (switching) {\n" +
				"//start by saying: no switching is done:\n" +
				"switching = false;\n" +
				"rows = table.getElementsByTagName(\"TR\");\n" +
				"/*Loop through all table rows (except the\n" +
				"first, which contains table headers):*/\n" +
				"for (i = 1; i < (rows.length - 1); i++) {\n" +
				"//start by saying there should be no switching:\n" +
				"shouldSwitch = false;\n" +
				"/*Get the two elements you want to compare,\n" +
				"one from current row and one from the next:*/\n" +
				"x = rows[i].getElementsByTagName(\"TD\")[n];\n" +
				"y = rows[i + 1].getElementsByTagName(\"TD\")[n];\n" +
				"/*check if the two rows should switch place,\n" +
				"based on the direction, asc or desc:*/\n" +
				"if (dir == \"asc\") {\n" +
				"if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {\n" +
				"//if so, mark as a switch and break the loop:\n" +
				"shouldSwitch= true;\n" +
				"break;\n" +
				"}\n" +
				"} else if (dir == \"desc\") {\n" +
				"if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {\n" +
				"//if so, mark as a switch and break the loop:\n" +
				"shouldSwitch= true;\n" +
				"break;\n" +
				"}\n" +
				"}\n" +
				"}\n" +
				"if (shouldSwitch) {\n" +
				"/*If a switch has been marked, make the switch\n" +
				"and mark that a switch has been done:*/\n" +
				"rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);\n" +
				"switching = true;\n" +
				"//Each time a switch is done, increase this count by 1:\n" +
				"switchcount ++;\n" +
				"} else {\n" +
				"/*If no switching has been done AND the direction is \"asc\",\n" +
				"set the direction to \"desc\" and run the while loop again.*/\n" +
				"if (switchcount == 0 && dir == \"asc\") {\n" +
				"dir = \"desc\";\n" +
				"switching = true;\n" +
				"}\n" +
				"}\n" +
				"}\n" +
				"}\n" +
				"</script>\n" +
				"<script>\n" +
				"// Load vip members into table\n" +
				"function loadviptable(app,wipid,vipid) {\n" +
				"// Construct a XMLHttpRequest object\n" +
				"var xhr = new XMLHttpRequest();\n" +
				"// Set up the readyState change event handler\n" +
				"xhr.onreadystatechange = function() {\n" +
				"if ((this.readyState === 4) && (this.status === 200)) {\n" +
				"if (this.responseText !== null) {\n" +
				"// Load the responseText into element with id=\"table4\"\n" +
				"var outElm = document.getElementById('table4');\n" +
				"outElm.innerHTML = this.responseText;\n" +
				"}\n" +
				"}\n" +
				"}\n" +
				"// Open an asynchronous POST connection and send request\n" +
				"xhr.open(\"GET\", \""+ getlblburlpath() + "/getmembers?app=\" + app + \"&&wipid=\" + wipid + \"&&vipid=\" + vipid, true);\n" +
				"xhr.send();\n" +
				"}\n" +
				"</script>\n" +
				"</body>\n" +
				"</html>\n";
	}

	public String getSideList() {
		
	   StringBuffer sb = new StringBuffer();
	   sb.append("<div class=\"sidelist card\">\n");
	   sb.append("<div class=\"container\">List of LBs</div>\n");
	   for (String app: getAppsList()) {
		   sb.append("<button onclick=\"myFunction('" + app +"')\"><b>" + app + "</b></button>\n");
		   sb.append("<div id=\"" + app + "\" class=\"w3-hide\">\n");
		   sb.append("<nav>\n");
		   sb.append("<ul>\n");
		   //for (String lb_wip : readFile("D:/tibco/webforms/inventory/files/"+ app +"_app_members")){
		   for (String lb_wip : readFile(getlbfiledir() + "/" + app +"_app_members")){
			   String[] st_lb_wip = lb_wip.split("\\|", -1);
			   sb.append("<li><a href=\""+ getlblburlpath() + "/getdetails?app="+ app + "&&wipid=" + st_lb_wip[0] + "\">" + st_lb_wip[4] + "</a></li>\n");
		   }
		   sb.append("</ul>\n");
		   sb.append("</nav>\n");
		   sb.append("</div>\n");
	   }
	   sb.append("</div>\n");
	   return sb.toString();
	}
	
	public String getHomePage() {
		StringBuffer sb = new StringBuffer();
		sb.append("<div class=\"fullpage card\">\n");
		sb.append("<div class=\"container\">Load Balancer Dashboard</div>\n");		
		return sb.toString();
		
	}
	
	
	public String getPages(String app, String wipid) {
		   StringBuffer sb = new StringBuffer();
		   StringBuffer sb1 = new StringBuffer();
		   StringBuffer sb2 = new StringBuffer();
		   String wlb = new String();
		   String alias = new String();
		   String shortapp = new String();
		   String method = new String();
		   
		   String vipprod = new String();
		   String vipdr = new String();
		   String vipcob = new String();
		   String vipcobalias = new String();
		   
		   sb.append("<div class=\"fullpage card\">\n");
		   sb.append("<div class=\"container\">Load Balancer Information</div>\n");
		   
		   //Page 1
		   sb.append("<div class=\"page1\">\n");
		   sb.append("<div class=\"container\" style=\"font-size: 11px;\">WIP DETAILS</div>");
		   //for (String lb_wip : readFile("D:/tibco/webforms/inventory/files/"+ app +"_app_members")){
		   for (String lb_wip : readFile(getlbfiledir() + "/" + app +"_app_members")){
			   String[] st_lb_wip = lb_wip.split("\\|", -1);
			   if ( st_lb_wip[0].equals(wipid)) {
				   
				   String vipactive=st_lb_wip[6];
				   
				   sb.append("<table>\n");
	//			   sb.append("<tr>\n");
	//			   sb.append("<th colspan=\"2\">WIP DETAILS</th>\n");
	//			   sb.append("</tr>\n");
				   sb.append("<tr>\n");
				   sb.append("<td><b>WLB NAME</b></td>\n");
				   sb.append("<td>"+ st_lb_wip[1] +"</td>\n");
				   sb.append("</tr>\n");
				   sb.append("<tr>\n");
				   sb.append("<td><b>ALIAS</b></td>\n");
				   sb.append("<td>"+ st_lb_wip[2] +"</td>\n");
				   sb.append("</tr>\n");
				   sb.append("<td><b>APPLICATION</b></td>\n");
				   sb.append("<td>"+ st_lb_wip[4] +"</td>\n");
				   sb.append("</tr>\n");
				   sb.append("<tr>\n");
				   sb.append("<td><b>METHOD</b></td>\n");
				   sb.append("<td>"+ st_lb_wip[5] +"</td>\n");
				   sb.append("</tr>\n");
				   sb.append("</table>\n");
				   sb.append("</div>\n");
				  
				   // Page 2
				   sb1.append("<div class=\"page2\">\n");
				   sb1.append("<div class=\"container\" style=\"font-size: 11px;\">LIST OF VIPS</div>");
				   sb1.append("<table>\n");
				 //  sb1.append("<tr>\n");
				  // sb1.append("<th colspan=\"2\">LIST OF VIPS</th>\n");
				 //  sb1.append("</tr>\n");
				   
				   // PAge3
				   sb2.append("<div class=\"page3\">\n");
				   sb2.append("<div class=\"container\" style=\"font-size: 11px;\">VIP DETAILS</div>\n");
				   sb2.append("<table id=\"table3\">\n");
				   sb2.append("<tr>\n");
				   sb2.append("<th onclick=\"sortTable(0,'table3')\">ENV</th>\n");
				   sb2.append("<th onclick=\"sortTable(1, 'table3')\">VIP</th>\n");
				   sb2.append("<th onclick=\"sortTable(2, 'table3')\">PORT</th>\n");
				   sb2.append("<th onclick=\"sortTable(2, 'table3')\">GSLB</th>\n");
				   sb2.append("<th onclick=\"sortTable(3, 'table3')\">STATUS</th>\n");
				   sb2.append("<th onclick=\"sortTable(4, 'table3')\">APPLICATION</th>\n");
				   sb2.append("</tr>\n");
				   
				   //for (String lb_vip : readFile("D:/tibco/webforms/inventory/files/"+ wipid +"_wip_members")){
				   for (String lb_vip : readFile(getlbfiledir() + "/" + wipid +"_wip_members")){
				   		String[] st_lb_vip = lb_vip.split("\\|", -1);
					   
					   if (st_lb_vip[5].equals("PROD") ) {
						   if (st_lb_vip[2].equals(vipactive))
							  vipprod=st_lb_vip[2] + " (ACTIVE)";
						   else vipprod=st_lb_vip[2];
					   } else if (st_lb_vip[5].equals("DR")) {
						   if (st_lb_vip[2].equals(vipactive))
							   vipdr=st_lb_vip[2] + " (ACTIVE)";
						   else vipdr=st_lb_vip[2];
					   } else if (st_lb_vip[5].equals("COB")) {
						   vipcob=st_lb_vip[2] ;
						   vipcobalias=st_lb_vip[3] ;
					   }
					   
					   sb2.append("<tr>\n");
					   sb2.append("<td>" + st_lb_vip[5] + "</td>\n");
					   sb2.append("<td>" + st_lb_vip[2] + "</td>\n");
					   sb2.append("<td>" + st_lb_vip[4] + "</td>\n");
					   sb2.append("<td>LIVE</td>\n");
					   sb2.append("<td></td>\n");
					   sb2.append("<td><button style=\"font-size: 10px;\" onclick=\"loadviptable('"+app+"','"+wipid+"','"+st_lb_vip[0] +"')\">Details</button></td>\n");
					   sb2.append("</tr>\n");
				   }
				
					   sb1.append("<tr>\n");
					   sb1.append("<td><b>PROD</b></td>\n");
					   sb1.append("<td>" + vipprod + "</td>\n");
					   sb1.append("</tr>\n");
					   sb1.append("<tr>\n");
					   sb1.append("<td><b>DR</b></td>\n");
					   sb1.append("<td>" + vipdr + "</td>\n");
					   sb1.append("</tr>\n");
					   sb1.append("<tr>\n");
					   sb1.append("<td><b>COB</b></td>\n");
					   sb1.append("<td>" + vipcob + "</td>\n");
					   sb1.append("</tr>\n");
					   sb1.append("<td><b>COB ALIAS</b></td>\n");
					   sb1.append("<td>" + vipcobalias + "</td>\n");
					   sb1.append("</tr>\n");
					
						sb2.append("</table>\n");
						sb2.append("</div>\n");
						sb1.append("</table>\n");
						sb1.append("</div>\n");
						
						sb1.append(sb2.toString());
						
						sb1.append("<div class=\"page4\">\n");
						sb1.append("<div class=\"container\" style=\"font-size: 11px;\">VIP MEMBERS</div>\n");
						sb1.append("<table id=\"table4\">\n");
						sb1.append("<tr>\n");
						sb1.append("<th onclick=\"sortTable(0,'table4')\">APPLICATION</th>\n");
						sb1.append("<th onclick=\"sortTable(1,'table4')\">SERVER VIP</th>\n");
						sb1.append("<th onclick=\"sortTable(2,'table4')\">SERVER</th>\n");
						sb1.append("<th onclick=\"sortTable(3,'table4')\">PORT</th>\n");
						sb1.append("<th onclick=\"sortTable(4,'table4')\">STATUS</th>\n");
						sb1.append("<th onclick=\"sortTable(5,'table4')\">LISTENER</th>\n");
						sb1.append("</tr>\n");
				   }
				   
			   }
		   sb.append(sb1);
		  
		   return sb.toString();
	}

	public String getPage4(String vipid) {
		
		StringBuffer sb = new StringBuffer();
		sb.append("<tr>\n");
		sb.append("<th onclick=\"sortTable(0,'table4')\">APPLICATION</th>\n");
		sb.append("<th onclick=\"sortTable(1,'table4')\">SERVER VIP</th>\n");
		sb.append("<th onclick=\"sortTable(2,'table4')\">SERVER</th>\n");
		sb.append("<th onclick=\"sortTable(3,'table4')\">PORT</th>\n");
		sb.append("<th onclick=\"sortTable(4,'table4')\">STATUS</th>\n");
		sb.append("<th onclick=\"sortTable(5,'table4')\">LISTENER</th>\n");
		sb.append("</tr>\n");

	    //for (String lb_vip_mem : readFile("D:/tibco/webforms/inventory/files/"+ vipid +"_vip_members")){
		for (String lb_vip_mem : readFile(getlbfiledir() + "/" + vipid +"_vip_members")){
			String[] st_lb_vip_mem = lb_vip_mem.split("\\|", -1);
		   sb.append("<tr>\n");
		   sb.append("<td>"+st_lb_vip_mem[0] +"</td>\n");
		   sb.append("<td>"+st_lb_vip_mem[1] +"</td>\n");
		   sb.append("<td>"+st_lb_vip_mem[2] +"</td>\n");
		   sb.append("<td>"+st_lb_vip_mem[3] +"</td>\n");
		   sb.append("<td>UP</td>\n");
		   sb.append("<td></td>\n");
		   sb.append("</tr>\n");		   
	   }
	    return sb.toString();	
	}
	
	
	public String getFooter(){	
		return footer;
	}
	
	public String getlbfiledir(){	
		//lbfiledir="D:/tibco/webforms/inventory/files";
		return lbfiledir;
	}	
	
	public String getlbappfile(){
		lbappfile=getlbfiledir()+"/apps.txt";
		return lbappfile;
	}	

	public String getlblburlpath(){	
		//lburlpath="/myservlet/lb";
		return lburlpath;
	}	
	
	public List<String> getAppsList(){	
		//return (readFile("D:/tibco/webforms/inventory/files/apps.txt"));
		
		return (readFile(getlbappfile()));
	}
	
	public commonResources(String lbdir,String lburl) {
		
		//System.out.println(lbdir + " - " + lburl);
		this.lbfiledir = lbdir;
		this.lburlpath = lburl;
		setHeader();
		setFooter();
	}

}
