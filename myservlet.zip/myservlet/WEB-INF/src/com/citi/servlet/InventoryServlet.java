package com.citi.servlet;

//To save as "<CATALINA_HOME>\webapps\helloservlet\WEB-INF\src\mypkg\HelloServlet.java"

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class InventoryServlet extends HttpServlet  {
	
   String lbRootDir ;
   String lbRootUrlPath;
   
   //Load Properties
   //@Override
   public void init(ServletConfig servletConfig) throws ServletException{
	   super.init(servletConfig);
	   this.lbRootDir = servletConfig.getInitParameter("lbRootDir");
	   this.lbRootUrlPath = servletConfig.getInitParameter("lbRootUrlPath");
	  // System.out.println(servletConfig.getInitParameterNames().toString());
	   /*
		Enumeration<?> enumeration =servletConfig.getInitParameterNames();
		while (enumeration.hasMoreElements()) {
			String key = (String) enumeration.nextElement();
		//	System.out.println("Key: "+key+"   Value: "+servletConfig.getInitParameter(key));				
		}
		*/
   }	

@Override
public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
   // Set the response message's MIME type
   response.setContentType("text/html;charset=UTF-8");
   // Allocate a output writer to write the response message into the network socket
   PrintWriter out = response.getWriter();
   
  // loadProperties();
   
   StringBuffer sb = new StringBuffer();
   commonResources com =new commonResources(lbRootDir, lbRootUrlPath);
   
   String url= request.getRequestURI();
   
   // Write the response message, in an HTML page
   try {
	   
	   //Inventory - /inventory/lb/*
	   if (url.contains("/lb")) {

		   String app=request.getParameter("app");
		   String wipid=request.getParameter("wipid");
		   String vipid=request.getParameter("vipid");
		   //System.out.print(app);
		   
		   
		   if (url.contains("/getmembers")) {
			   sb = new StringBuffer();
			   sb.append(com.getPage4(vipid));
			
		   } else if (url.contains("/getdetails")) {
			   sb = new StringBuffer();
			   sb.append(com.getHeader());
			   sb.append(com.getSideList());
			   sb.append(com.getPages(app, wipid));
			   sb.append(com.getFooter());
			   
		   }
		   
		   // if (url.equals(com.getlblburlpath()) || url.equals(com.getlblburlpath() + "/") ){
		   else {
			   sb = new StringBuffer();
			   sb.append(com.getHeader());
			   sb.append(com.getSideList());
			   sb.append(com.getHomePage());
			   sb.append(com.getFooter());
		   }
		   
	   }
	   out.print(sb);

   }finally {
      out.close();  // Always close the output writer
   }
}
}