package com.citi.servlet;
import java.io.*;


public class testing {

	public static void main(String args[]) {
		
   StringBuffer sb = new StringBuffer();
   commonResources com =new commonResources(null, null);
   String app="CI";
   String wipid="W0001";
   String vipid="V0001";
   
   if (app.length() > 0 &&wipid.length() > 0 && vipid.length() >0 ) {
   
	//   sb.append(com.getHeader());
	 //  sb.append(com.getSideList());
	 //  sb.append(com.getPages(app, wipid));
	   sb.append(com.getPage4(vipid));
	   
   
   }else {
	   sb.append(com.getHeader());
	   sb.append(com.getSideList());
	   sb.append(com.getPages(app, wipid));
	   sb.append(com.getFooter());
   }
   
   
   System.out.println(sb);
   
   } 
}
